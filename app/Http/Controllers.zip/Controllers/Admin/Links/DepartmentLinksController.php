<?php

namespace App\Http\Controllers\Admin\Links;

use App\Http\Controllers\Controller;
use App\Models\Link;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class DepartmentLinksController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

        return view('admin.links.index', ['title' => 'Links']);
    }

    public function getlinks(Request $request)
    {
        $columns = array(
            0 => 'id',
            1 => 'name',
            2 => 'url',
            3 => 'title',
            4 => 'created_at',
            5 => 'updated_at',
            6 => 'action'
        );

        $totalData = Link::count();
        $limit = $request->input('length');
        $start = $request->input('start');
        $order = $columns[$request->input('order.0.column')];
        $dir = $request->input('order.0.dir');

        if (empty($request->input('search.value'))) {
            $links= Link::offset($start)
                ->limit($limit)
                ->orderBy($order, $dir)
                ->get();
            $totalFiltered = Link::count();
        } else {
            $search = $request->input('search.value');
            $links = Link::where('title', 'like', "%{$search}%")
                ->offset($start)
                ->limit($limit)
                ->orderBy($order, $dir)
                ->get();
            $totalFiltered = Link::where('name', 'like', "%{$search}%")
                ->count();
        }


        $data = array();

        if ($links) {
            foreach ($links as $r) {
                $edit_url = route('links.edit', $r->id);
                $nestedData['id'] = '<td><label class="checkbox checkbox-outline checkbox-success"><input type="checkbox" name="categories[]" value="'.$r->id.'"><span></span></label></td>';
                $nestedData['name'] = $r->name;
                $nestedData['url'] = $r->url;
                $nestedData['title'] = $r->title;
                $nestedData['created_at'] = date('Y-m-d h:m:s a', strtotime($r->created_at));
                $nestedData['updated_at'] = date('Y-m-d h:m:s a', strtotime($r->updated_at));
                $nestedData['action'] = '
                                <div>
                                <td>
                                    <a title="Edit Link" class="btn btn-sm btn-clean btn-icon"
                                       href="'.$edit_url.'">
                                       <i class="icon-1x text-dark-50 flaticon-edit"></i>
                                    </a>
                                    <a class="btn btn-sm btn-clean btn-icon" onclick="event.preventDefault();del('.$r->id.');" title="Delete Link" href="javascript:void(0)">
                                        <i class="icon-1x text-dark-50 flaticon-delete"></i>
                                    </a>
                                </td>
                                </div>
                            ';

                $data[] = $nestedData;
            }
        }

        $json_data = array(
            "draw"			=> intval($request->input('draw')),
            "recordsTotal"	=> intval($totalData),
            "recordsFiltered" => intval($totalFiltered),
            "data"			=> $data
        );

        echo json_encode($json_data);

    }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.links.create', ['title' => 'Create links']);

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function store(Request $request)
    {
        // dd($request->all());
        $validatedData = $this->validate($request, [
            'name' => 'required|min:3|string',
            'url' => 'required|min:3|string',
            'title' => 'required|min:3|string',
        ]);
        if ($request->hasFile('attachment')) {
            if ($request->file('attachment')->isValid()) {
                $this->validate($request, [
                    'attachment' => '|image|mimes:jpeg,png,jpg,pdf,xml,txt'
                ]);
                $file = $request->file('attachment');
                $destinationPath = public_path('/uploads/');
                $attachment = $file->getClientOriginalName('attachment');
                $attachment = rand() . $attachment;
                $request->file('attachment')->move($destinationPath, $attachment);
                $validatedData['attachment'] = $attachment;
            }
        }
        Link::create($validatedData);

        return redirect()->back();
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }
    public function linkDetail(Request $request)
    {
        /*dd('working');*/
        $links = Link::findOrFail($request->id)->first();
        return view('admin.articles.show', ['title' => 'Show Links', 'links' => $links]);
    }
    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $link = Link::findOrFail($id);
        return view('admin.links.edit', ['title' => 'Edit Links', 'link' => $link]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $link = Link::findOrFail($id);
        $link['name'] =$request->input('name');
        $link['url'] =$request->input('url');
        $link['title'] =$request->input('title');
        if ($request->hasFile('attachment')) {
            if ($request->file('attachment')->isValid()) {
                $this->validate($request, [
                    'attachment' => '|image|mimes:jpeg,png,jpg,pdf,xml,txt'
                ]);
                $file = $request->file('attachment');
                $destinationPath = public_path('/uploads/');
                $attachment = $file->getClientOriginalName('attachment');
                $attachment = rand() . $attachment;
                $request->file('attachment')->move($destinationPath, $attachment);
                $link['attachment'] = $attachment;
            }
        }
        $link->save();
        Session::flash('success_message', 'Success! Link has been updated successfully!');
        return redirect()->route('links.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $link = Link::findOrFail($id);
        $link->delete();
        Session::flash('success_message', 'Success! Link successfully deleted!');
        return redirect()->back();
    }
    public function DeleteSelectedVehicle(Request $request)
    {
        $this->validate($request, [
            'link' => 'required',
        ]);

        foreach ($request->input('link') as $index => $link_id) {
            $link = Link::findOrFail($link_id);
            $link->delete();
        }
        Session::flash('success_message', 'Success! Links successfully deleted!');
        return redirect()->back();

    }
}
