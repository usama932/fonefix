<?php

namespace App\Http\Controllers\Admin\FleetManagement;

use App\Http\Controllers\Controller;
use App\Mail\fleetTicketmail;
use App\Models\FleetComplaint;
use App\Models\FleetTicket;
use App\Models\TicketImage;
use App\Models\Vehicle;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Str;

class FleetTicketController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\Contracts\View\View
     */

    public function index()
    {

        return view('admin.tickets.index', ['title' => 'Tickets']);
    }

    public function getTickets(Request $request)
    {
        $columns = array(
            0 => 'id',
            1 => 'vehicle_id',
            2 => 'complaint',
            3 => 'remarks',
            4 => 'vehicle_mileage',
            5 => 'status',
            6 => 'created_at',
            7 => 'action'
        );

        $totalData = FleetTicket::where('status',0)->count();
        // dd($totalData);
        $limit = $request->input('length');
        $start = $request->input('start');
        $order = $columns[$request->input('order.0.column')];
        $dir = $request->input('order.0.dir');

        if (empty($request->input('search.value'))) {
            $tickets = FleetTicket::offset($start)
                ->limit($limit)
                ->orderBy($order, $dir)
                ->where('status',0)
                ->get();
                // dd($tickets);
            $totalFiltered = FleetTicket::where('status',0)->count();
        } else {
            $search = $request->input('search.value');
            $tickets = FleetTicket::where('id', 'like', "%{$search}%")
                ->offset($start)
                ->limit($limit)
                ->orderBy($order, $dir)
                ->get();
            $totalFiltered = FleetTicket::where('id', 'like', "%{$search}%")
                ->count();
        }


        $data = array();
        if ($tickets) {
            foreach ($tickets as $r) {
                $edit_url = route('tickets.edit', $r->id);
                $nestedData['id'] = '<td><label class="checkbox checkbox-outline checkbox-success"><input type="checkbox" name="categories[]" value="'.$r->id.'"><span></span></label></td>';
                $nestedData['remarks'] = $r->remarks;
                $nestedData['vehicle_mileage'] = $r->vehicle_mileage;
                if($r->vehicles){
                    $nestedData['vehicle_id'] = $r->vehicles->vehicle_no;
                }else{
                    $nestedData['vehicle_id'] = '<span class="label label-lg font-weight-bold  label-light-danger label-inline">No Vehicle</span>';
                }
                if($r->complaint){
                    $nestedData['complaint_id'] = '<span class="label label-lg font-weight-bold  label-light-info label-inline">'.$r->complaint.'</span>';
                }else{
                    $nestedData['complaint_id'] = '<span class="label label-lg font-weight-bold  label-light-danger label-inline">No Complaints</span>';
                }
                if ($r->status == 1) {
                    $nestedData['status'] = '<span class="label label-lg font-weight-bold  label-light-info label-inline">In-Service</span>';
                } elseif ($r->status == 0) {
                    /*label label-danger label-inline mr-2*/
                    $nestedData['status'] = '<span class="label label-lg font-weight-bold  label-light-danger label-inline">Out Of Service</span>';
                }
                $nestedData['created_at'] = date('Y-m-d h:m:s a', strtotime($r->created_at));
                $nestedData['updated_at'] = date('Y-m-d h:m:s a', strtotime($r->updated_at));
                $nestedData['action'] = '
                                <div>
                                <td>
                                    <a class="btn btn-sm btn-clean btn-icon" onclick="event.preventDefault();viewInfo('.$r->id.');" title="View Article" href="javascript:void(0)">
                                        <i class="icon-1x text-dark-50 flaticon-eye"></i>
                                    </a>
                                    <a title="Edit Article" class="btn btn-sm btn-clean btn-icon"
                                       href="'.$edit_url.'">
                                       <i class="icon-1x text-dark-50 flaticon-edit"></i>
                                    </a>
                                    <a class="btn btn-sm btn-clean btn-icon" onclick="event.preventDefault();del('.$r->id.');" title="Delete Article" href="javascript:void(0)">
                                        <i class="icon-1x text-dark-50 flaticon-delete"></i>
                                    </a>
                                </td>
                                </div>
                            ';

                $data[] = $nestedData;
            }
        }

        $json_data = array(
            "draw"			=> intval($request->input('draw')),
            "recordsTotal"	=> intval($totalData),
            "recordsFiltered" => intval($totalFiltered),
            "data"			=> $data
        );

        echo json_encode($json_data);

    }

    public function getArticle(Request $request)
    {
        $ticket = FleetTicket::findOrFail($request->input('id'));
        return view('admin.tickets.single', ['title' => 'Edit Ticket', 'ticket' => $ticket]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\Contracts\View\View
     */
    public function create()
    {
        $vehicles = Vehicle::all();
//        $complaints = FleetComplaint::all();
        return view('admin.tickets.create', ['title' => 'Create Events', 'vehicles' => $vehicles]);

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function store(Request $request)
    {
//       dd($request->all());
        $validatedData = $this->validate($request, [
            'complaint' => 'required',
            'vehicle_id' => 'required',
            'remarks' => 'required',
//            'vehicle_mileage' => 'required| numeric',
        ]);
        $input = $request->all();
        $status = $request->status;
        $validatedData['status'] = $status;
        $email = Auth::user()->email;



//        dd($validatedData);
        $ticket = FleetTicket::create($validatedData);
        // dd($ticket);
        $data = array(
            'name' => "Ticket",
            'subject' => "Fleet Tickets Generated Successfully ",
            'msg' => "Your fleet ticket  has generated ",
            'email' => $email,
            'logo' => isset($settings['admin_logo']) ? $settings['admin_logo'] : '',
            'site_title' => isset($settings['site_title']) ? $settings['site_title'] : 'iNet Ventures',
        );
// dd($ticket);
//        dd($ticket);
        // if(array_key_exists('uploadedImages', $input)){
        //     foreach ($request->uploadedImages as $key => $picture) {
        //         $ticketImage = new TicketImage();
        //         $ticketImage->ticket_id = $ticket->id;
        //         $ticketImage->image = $picture;
        //         $ticketImage->type = 1;
        //         $ticketImage->save();
        //     }
        // }
        Mail::to($data['email'])->send(new fleetTicketmail($data));


        Session::flash('success_message', 'Success! Fleet Ticket has been created successfully!');
        return redirect()->route("tickets.index");
    }

    public function saveTicketImages(Request $request)
    {
        $image = $request->file('file');
        //$imageName = time() . $image->getClientOriginalName();
        $imageName = $image->getClientOriginalName();
//        $imageName = time().$imageName;
        $image->move('uploads/', $imageName);
        $id  = $this->clean($imageName);
        return response()->json(['imageName' => $imageName,'id'=>$id]);
    }
    public function deleteImage($id){
        $name = explode('.',$id);
        $delete_old_file="uploads".$id;
        TicketImage::delete($delete_old_file);
        $id  = $this->clean($id);
        return response()->json(['id' =>$id]);
    }
    public function  clean($string) {
        $string = str_replace(' ', '-', $string); // Replaces all spaces with hyphens.

        return preg_replace('/[^A-Za-z0-9\-]/', '', $string); // Removes special chars.
    }
    public function deleteTicketImage($ticket_id, $image_id){
        $ticketImage =  TicketImage::where('id',$image_id)->first();
        if ($ticketImage)
        {
            $ticketImage->delete();
            $delete_old_file="uploads".$ticketImage->image;
            TicketImage::delete($delete_old_file);
        }
        return redirect()->back()->withSuccess('Stamp image has been deleted successfuly.');
    }

    /**
     * Display the specified resource.
     *
     * @param int $id
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\Contracts\View\View
     */
    public function show($id)
    {
        /*$article = Article::findOrFail($id);
        $categories = Category::orderBy('name', 'asc')->pluck('name', 'id')->toArray();
        return view('admin.articles.show', ['title' => 'Edit Article', 'article' => $article, 'categories' => $categories]);*/
    }
    public function ticketDetail(Request $request)
    {
        /*dd('working');*/
        $ticket = FleetTicket::findOrFail($request->id)->first();
        // dd($ticket);
        return view('admin.tickets.show', ['title' => 'Ticket Detail', 'ticket' => $ticket]);
    }
    /**
     * Show the form for editing the specified resource.
     *
     * @param int $id
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\Contracts\View\View
     */
    public function edit($id)
    {
        $ticket = FleetTicket::where("id",$id)->with('vehicles')->first();
//        dd($ticket);
//        $complaints = FleetComplaint::all();
        $vehicles = Vehicle::all();
        return view('admin.tickets.edit', ['title' => 'Edit Ticket','vehicles' => $vehicles, 'ticket' => $ticket]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @param int $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function update(Request $request, $id)
    {
        $ticket = FleetTicket::findOrFail($id);
        $input = $request->all();
        $ticket['remarks'] =$request->input('remarks');
        $ticket['complaint'] =$request->input('complaint');
        $ticket['vehicle_mileage'] =$request->input('vehicle_mileage');
        $status = $request->input('status');
//        if ($status == null) {
//            $status = 0;
//        } else {
//            $status = 1;
//        }
        $ticket['status'] = $status;
        $ticket->save();

        if(array_key_exists('uploadedImages', $input)){
            foreach ($request->uploadedImages as $key => $picture) {
                $ticketImage = new TicketImage();
                $ticketImage->ticket_id = $ticket->id;
                $ticketImage->image = $picture;
                $ticketImage->type = 1;
                $ticketImage->save();
            }
        }
        Session::flash('success_message', 'Success! Ticket has been updated successfully!');
        return redirect()->back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param int $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function destroy($id)
    {
        $ticket = FleetTicket::findOrFail($id);
        $ticket->vehicles();
        // $ticket->complaints()->detach();
        $ticket->delete();
        Session::flash('success_message', 'Success! FLeet Tickets  successfully deleted!');
        return redirect()->route('tickets.index');
    }

    public function DeleteSelectedArticle(Request $request)
    {
        $this->validate($request, [
            'fleet_ticket' => 'required',
        ]);

        foreach ($request->input('fleet_ticket') as $index => $ticket_id) {
            $ticket = FleetTicket::findOrFail($ticket_id);
            $ticket->vehicles()->detach();
            $ticket->complaints()->detach();
            $ticket->delete();
        }
        Session::flash('success_message', 'Success! FLeet Tickets successfully deleted!');
        return redirect()->back();

    }
}
