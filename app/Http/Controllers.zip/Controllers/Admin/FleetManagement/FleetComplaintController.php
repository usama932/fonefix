<?php

namespace App\Http\Controllers\Admin\FleetManagement;

use App\Http\Controllers\Controller;
use App\Models\FleetComplaint;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Str;

class FleetComplaintController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\Contracts\View\View
     */
    public function index()
    {
        return view('admin.fleet_complaints.index', ['title' => 'Event Categories']);

    }
    public function getFleetComplaints(Request $request)
    {
        $columns = array(
            0 => 'id',
            1 => 'name',
            2 => 'slug',
            3 => 'created_at',
            4 => 'action',
        );
        $totalData = FleetComplaint::count();
        $limit = $request->input('length');
        $start = $request->input('start');
        $order = $columns[$request->input('order.0.column')];
        $dir = $request->input('order.0.dir');
        if (empty($request->input('search.value'))) {
            $fleet_complaint = FleetComplaint::offset($start)
                ->limit($limit)
                ->orderBy($order, $dir)
                ->get();
            $totalFiltered = FleetComplaint::count();
        } else {
            $search = $request->input('search.value');
            $fleet_complaint = FleetComplaint::where('name', 'like', "%{$search}%")
                ->orWhere('slug', 'like', "%{$search}%")
                ->orWhere('created_at', 'like', "%{$search}%")
                ->offset($start)
                ->limit($limit)
                ->orderBy($order, $dir)
                ->get();
            $totalFiltered = FleetComplaint::where('name', 'like', "%{$search}%")
                ->orWhere('slug', 'like', "%{$search}%")
                ->count();
        }
        $data = array();
        if ($fleet_complaint) {
            foreach ($fleet_complaint as $r) {
                $edit_url = route('fleet-complaints.edit', $r->id);
                $nestedData['id'] = '<td><label class="checkbox checkbox-outline checkbox-success"><input type="checkbox" name="fleet_complaints[]" value="' . $r->id . '"><span></span></label></td>';
                $nestedData['name'] = $r->name;
                $nestedData['slug'] = $r->slug;
                $nestedData['created_at'] = date('Y-m-d h:m:s a', strtotime($r->created_at));
                $nestedData['updated_at'] = date('Y-m-d h:m:s a', strtotime($r->updated_at));
                $nestedData['action'] = '
                          <div>
                                <td>
                                    <a class="btn btn-sm btn-clean btn-icon" onclick="event.preventDefault();viewInfo(' . $r->id . ');" title="View Fleet Complaint" href="javascript:void(0)">
                                        <i class="icon-1x text-dark-50 flaticon-eye"></i>
                                    </a>
                                    <a title="Edit Fleet Complaint" class="btn btn-sm btn-clean btn-icon"
                                       href="' . $edit_url . '">
                                       <i class="icon-1x text-dark-50 flaticon-edit"></i>
                                    </a>
                                    <a class="btn btn-sm btn-clean btn-icon" onclick="event.preventDefault();del(' . $r->id . ');" title="Delete Fleet Complaint" href="javascript:void(0)">
                                        <i class="icon-1x text-dark-50 flaticon-delete"></i>
                                    </a>
                                </td>
                                </div>
                            ';
                $data[] = $nestedData;
            }
        }

        $json_data = array(
            "draw" => intval($request->input('draw')),
            "recordsTotal" => intval($totalData),
            "recordsFiltered" => intval($totalFiltered),
            "data" => $data
        );

        echo json_encode($json_data);
    }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\Contracts\View\View
     */
    public function create()
    {
        return view('admin.fleet_complaints.create', ['title' => 'Create Fleet Complaints']);

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validatedData = $this->validate($request, [
            'name' => 'required',
        ]);
        $validatedData['slug'] = $this->createSlug($request->input('name'), 0);
        FleetComplaint::create($validatedData);
        Session::flash('success_message', 'Success! Category has been updated successfully!');
        return redirect()->back();
    }
    public function createSlug($title, $id)
    {
        $slug = Str::slug($title);
        $allSlugs = $this->getRelatedSlugs($slug, $id);
        for ($i = 1; $i <= 10; $i++) {
            $newSlug = $slug . '-' . $i;
            if (!$allSlugs->contains('slug', $newSlug)) {
                return $newSlug;
            }
        }
        throw new\Excprion('Can not create a unique slug');
    }

    protected function getRelatedSlugs($slug, $id)
    {
        return FleetComplaint::select('slug')->where('slug', 'like', $slug . '%')
            ->where('id', '<>', $id)
            ->get();
    }
    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\Contracts\View\View
     */
    public function show($id)
    {
        $fleet_complaints= FleetComplaint::findOrFail($id);
        return view('admin.fleet_complaints.detail', ['title' => 'Show Fleet Complaint', 'fleet_complaints' => $fleet_complaints]);
    }
    public function fleetComplaintDetail(Request $request)
    {
        /*dd('working');*/
        $fleet_complaint = FleetComplaint::findOrFail($request->id);
        return view('admin.fleet_complaints.detail', ['title' => 'Show Fleet Complaint','fleet_complaint' => $fleet_complaint]);
    }
    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\Contracts\View\View
     */
    public function edit($id)
    {
        $fleet_complaint = FleetComplaint::findOrFail($id);

        return view('admin.fleet_complaints.edit', ['title' => 'Edit Fleet Complaint', 'fleet_complaint' => $fleet_complaint]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function update(Request $request, $id)
    {
        $fleet_complaint = FleetComplaint::findOrFail($id);


        $fleet_complaint['name'] =$request->input('name');
        $fleet_complaint['slug'] = $this->createSlug($request->input('name'), 0);
//            dd($category);
        $fleet_complaint->save();
        Session::flash('success_message', 'Success! Fleet Complaint has been updated successfully!');
        return redirect()->back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $fleet_complaint = FleetComplaint::findOrFail($id);
        $fleet_complaint->delete();
        Session::flash('success_message', 'Success! Fleet Complain deleted');
        return redirect()->back();
    }
    public function deleteSelectedFleetComplaints(Request $request)
    {
        $input = $request->all();
        $this->validate($request, [
            'fleet_complaint' => 'required',
        ]);
        foreach ($input['fleet_complaint'] as $index => $id) {

            $fleet_complaint = FleetComplaint::find($id);
            $fleet_complaint->delete();
        }
        Session::flash('success_message', 'successfully deleted!');
        return redirect()->back();
    }
}
