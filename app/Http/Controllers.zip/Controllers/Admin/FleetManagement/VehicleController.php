<?php

namespace App\Http\Controllers\Admin\FleetManagement;

use App\Http\Controllers\Controller;
use App\Models\Vehicle;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;

class VehicleController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\Contracts\View\View
     */
    public function index()
    {
        return view('admin.vehicles.index', ['title' => 'Vehicles']);

    }
    public function getVehicles(Request $request)
    {
        $columns = array(
            0 => 'id',
            1 => 'vehicle_no',
            2 => 'registration_no',
            3 => 'year',
            4 => 'make',
            5 => 'model',
            6 => 'notes',
            7 => 'created_at',
            9 => 'action'
        );

        $totalData = Vehicle::count();
        $limit = $request->input('length');
        $start = $request->input('start');
        $order = $columns[$request->input('order.0.column')];
        $dir = $request->input('order.0.dir');

        if (empty($request->input('search.value'))) {
            $vehicles = Vehicle::offset($start)
                ->limit($limit)
                ->orderBy($order, $dir)
                ->get();
            $totalFiltered = Vehicle::count();
        } else {
            $search = $request->input('search.value');
            $vehicles = Vehicle::where('vehicle_no', 'like', "%{$search}%")
                ->offset($start)
                ->limit($limit)
                ->orderBy($order, $dir)
                ->get();
            $totalFiltered = Vehicle::where('vehicle_no', 'like', "%{$search}%")
                ->count();
        }


        $data = array();

        if ($vehicles) {
            foreach ($vehicles as $r) {
                $edit_url = route('vehicles.edit', $r->id);
                $nestedData['id'] = '<td><label class="checkbox checkbox-outline checkbox-success"><input type="checkbox" name="categories[]" value="'.$r->id.'"><span></span></label></td>';
                $nestedData['vehicle_no'] = $r->vehicle_no;
                $nestedData['Registration_no'] = $r->Registration_no;
                $nestedData['year'] = $r->year;
                $nestedData['make'] = $r->make;
                $nestedData['model'] = $r->model;
                $nestedData['notes'] = $r->notes;
                $nestedData['created_at'] = date('Y-m-d h:m:s a', strtotime($r->created_at));
                $nestedData['action'] = '
                                <div>
                                <td>
                                    <a class="btn btn-sm btn-clean btn-icon" onclick="event.preventDefault();viewInfo('.$r->id.');" title="View Vehicle" href="javascript:void(0)">
                                        <i class="icon-1x text-dark-50 flaticon-eye"></i>
                                    </a>
                                    <a title="Edit Vehicle" class="btn btn-sm btn-clean btn-icon"
                                       href="'.$edit_url.'">
                                       <i class="icon-1x text-dark-50 flaticon-edit"></i>
                                    </a>
                                    <a class="btn btn-sm btn-clean btn-icon" onclick="event.preventDefault();del('.$r->id.');" title="Delete Vehicle" href="javascript:void(0)">
                                        <i class="icon-1x text-dark-50 flaticon-delete"></i>
                                    </a>
                                </td>
                                </div>
                            ';

                $data[] = $nestedData;
            }
        }

        $json_data = array(
            "draw"			=> intval($request->input('draw')),
            "recordsTotal"	=> intval($totalData),
            "recordsFiltered" => intval($totalFiltered),
            "data"			=> $data
        );

        echo json_encode($json_data);

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\Contracts\View\View
     */
    public function create()
    {
        return view('admin.vehicles.create', ['title' => 'Add Vehicle']);

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function store(Request $request)
    {
        $validatedData = $this->validate($request, [
            'vehicle_no' => 'required',
            'Registration_no' => 'required',
            'year' => 'required',
            'make' => 'required',
            'model' => 'required',
            'notes' => 'required',
        ]);

        $validatedData['image']= $request->input('image');
//        dd($validatedData);
        Vehicle::create($validatedData);
        Session::flash('success_message', 'Success! Vehicle has been Added successfully!');
        return redirect()->back();
    }
    public function saveVehicleImage(Request $request)
    {

        $image = $request->file('file');
        //$imageName = time() . $image->getClientOriginalName();
        $imageName = $image->getClientOriginalName();
//        $imageName = time().$imageName;
        $image->move('uploads/', $imageName);
        $id  = $this->clean($imageName);
        return response()->json(['imageName' => $imageName,'id'=>$id]);
    }
    public function deleteImage($id){
        $name = explode('.',$id);
        $delete_old_file="uploads/".$id;
        File::delete($delete_old_file);
        $id  = $this->clean($id);
        return response()->json(['id' =>$id]);
    }
    public function  clean($string) {
        $string = str_replace(' ', '-', $string); // Replaces all spaces with hyphens.

        return preg_replace('/[^A-Za-z0-9\-]/', '', $string); // Removes special chars.
    }
    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\Contracts\View\View
     */
    public function show($id)
    {
        $vehicles = Vehicle::findOrFail($id);
        return view('admin.vehicles.detail', ['title' => 'Show Vehicles', 'vehicles' => $vehicles]);
    }
    public function vehicleDetail(Request $request)
    {
        /*dd('working');*/
        $id = $request->id;
        $vehicles = Vehicle::findOrFail($id);
        // dd($vehicles);
        return view('admin.vehicles.show', ['title' => 'Vehicle Detail','vehicles' => $vehicles]);
    }
    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\Contracts\View\View
     */
    public function edit($id)
    {
        $vehicle = Vehicle::findOrFail($id);
        return view('admin.vehicles.edit', ['title' => 'Edit Vehicle', 'vehicle' => $vehicle]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function update(Request $request, $id)
    {
        $vehicle = Vehicle::findOrFail($id);
        $vehicle->save();
        Session::flash('success_message', 'Success! Vehicle has been updated successfully!');
        return redirect()->back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function destroy($id)
    {
        $vehicle = Vehicle::findOrFail($id);
        $vehicle->delete();
        Session::flash('success_message', 'Success! Vehicle successfully deleted!');
        return redirect()->route('admin.vehicles.index');
    }
    public function DeleteSelectedVehicle(Request $request)
    {
        $this->validate($request, [
            'vehicle' => 'required',
        ]);

        foreach ($request->input('vehicle') as $index => $vehicle_id) {
            $vehicle = Vehicle::findOrFail($vehicle_id);
            $vehicle->delete();
        }
        Session::flash('success_message', 'Success! Vehicles successfully deleted!');
        return redirect()->back();

    }
}
