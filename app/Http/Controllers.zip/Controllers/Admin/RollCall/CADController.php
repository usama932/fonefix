<?php

namespace App\Http\Controllers\Admin\RollCall;

use App\Http\Controllers\Controller;
use App\Models\Article;
use App\Models\FleetTicket;
use App\Models\Vehicle;
use Illuminate\Http\Request;

class CADController extends Controller
{
    function index(){
        $vehicles = Vehicle::all();
        $articles = Article::all();
        $tickets = FleetTicket::all();
        return view('admin.rollcalls.cad_index',['title'=>'CAD_Dashboard', 'vehicles'=>$vehicles, 'articles'=>$articles, 'tickets'=>$tickets]);
    }
    function hoursCad(){
        $vehicles = Vehicle::all();
        $articles = Article::all();
        $tickets = FleetTicket::all();
        return view('admin.rollcalls.hours_cad',['title'=>'CAD_Dashboard', 'vehicles'=>$vehicles, 'articles'=>$articles, 'tickets'=>$tickets]);
    }
    function arrestLog(){
        $vehicles = Vehicle::all();
        $articles = Article::all();
        $tickets = FleetTicket::all();
        return view('admin.rollcalls.arrest_log',['title'=>'CAD_Dashboard', 'vehicles'=>$vehicles, 'articles'=>$articles, 'tickets'=>$tickets]);
    }
}
