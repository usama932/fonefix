<?php

namespace App\Http\Controllers\Admin\Documents;

use App\Http\Controllers\Controller;
use App\Models\Folder;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class FolderController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
	    $title = 'Document';
	    return view('admin.folders.index',compact('title'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */

	public function get(Request $request){
		$columns = array(
			0 => 'id',
			1 => 'name',
			2 => 'id',
			3 => 'created_at',
			4 => 'action'
		);

		$totalData = Folder::count();
		$limit = $request->input('length');
		$start = $request->input('start');
		$order = $columns[$request->input('order.0.column')];
		$dir = $request->input('order.0.dir');

		if(empty($request->input('search.value'))){
			$users = Folder::offset($start)
				->limit($limit)
				->orderBy($order,$dir)
				->get();
			$totalFiltered = Folder::count();
		}else{
			$search = $request->input('search.value');
			$users = Folder::where([
				['name', 'like', "%{$search}%"],
			])
				->orWhere('created_at','like',"%{$search}%")
				->offset($start)
				->limit($limit)
				->orderBy($order, $dir)
				->get();
			$totalFiltered = Folder::where([
				['name', 'like', "%{$search}%"],
			])
				->orWhere('name', 'like', "%{$search}%")
				->orWhere('created_at','like',"%{$search}%")
				->count();
		}


		$data = array();

		if($users){
			foreach($users as $r){
				$edit_url = route('folders.edit',$r->id);
				$show_url = route('folders.show',$r->id);
				$nestedData['id'] = '<td><label class="checkbox checkbox-outline checkbox-success"><input type="checkbox" name="folders[]" value="'.$r->id.'"><span></span></label></td>';
				$nestedData['name'] = $r->name;
				$docs= $r->documents->count() ;
				$nestedData['documents'] = '<a href="'.$show_url.'" class="label label-lg font-weight-bold  label-light-info label-inline">'.$docs ." Documents".'</a>';


				$nestedData['created_at'] = date('d-m-Y',strtotime($r->created_at));
				$nestedData['action'] = '
                                <div>
                                <td>
                                    <a class="btn btn-sm btn-clean btn-icon" onclick="event.preventDefault();viewInfo('.$r->id.');" title="View " href="javascript:void(0)">
                                        <i class="icon-1x text-dark-50 flaticon-eye"></i>
                                    </a>
                                    <a title="Edit " class="btn btn-sm btn-clean btn-icon"
                                       href="'.$edit_url.'">
                                       <i class="icon-1x text-dark-50 flaticon-edit"></i>
                                    </a>
                                    <a class="btn btn-sm btn-clean btn-icon" onclick="event.preventDefault();del('.$r->id.');" title="Delete " href="javascript:void(0)">
                                        <i class="icon-1x text-dark-50 flaticon-delete"></i>
                                    </a>
                                </td>
                                </div>
                            ';
				$data[] = $nestedData;
			}
		}

		$json_data = array(
			"draw"			=> intval($request->input('draw')),
			"recordsTotal"	=> intval($totalData),
			"recordsFiltered" => intval($totalFiltered),
			"data"			=> $data
		);

		echo json_encode($json_data);

	}
    public function create()
    {
	    $title = 'Add New Folder';
	    return view('admin.folders.create',compact('title'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
	    $this->validate($request, [
		    'name' => 'required|max:255',
	    ]);

	    $input = $request->all();
	    $user = new Folder();
	    $user->name = $input['name'];

	    $user->save();

	    Session::flash('success_message', 'Great! Folder has been saved successfully!');
	    $user->save();
	    return redirect()->back();
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
	    $user = Folder::find($id);
	    return view('admin.documents.show', ['title' => 'Folder detail', 'folder' => $user]);
    }

	public function detail(Request $request)
	{

		$user = Folder::findOrFail($request->id);
		return view('admin.folders.detail', ['title' => 'Folder Detail', 'user' => $user]);
	}

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
	    $user = Folder::find($id);
	    return view('admin.folders.edit', ['title' => 'Edit Folder details'])->withUser($user);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
	    $user = Folder::find($id);
	    $this->validate($request, [
		    'name' => 'required|max:255',
	    ]);
	    $input = $request->all();

	    $user->name = $input['name'];

	    $user->save();

	    Session::flash('success_message', 'Great! Folder successfully updated!');
	    return redirect()->back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
		dd($id);
	    $user = Folder::find($id);
		    $user->delete();
		    Session::flash('success_message', 'Folder successfully deleted!');
	    return redirect()->route('folders.index');

    }
	public function deleteSelected(Request $request)
	{
		$input = $request->all();
		$this->validate($request, [
			'folders' => 'required',

		]);
		foreach ($input['folders'] as $index => $id) {

			$user = Folder::find($id);
				$user->delete();

		}
		Session::flash('success_message', 'Folders successfully deleted!');
		return redirect()->back();

	}
}
