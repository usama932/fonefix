<?php

namespace App\Http\Controllers\Admin\Documents;

use App\Http\Controllers\Controller;
use App\Models\Document;
use App\Models\Folder;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class DocumentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
	    $title = 'Document';
	    return view('admin.documents.index',compact('title'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */

	public function get(Request $request){
		$columns = array(
			0 => 'id',
			1 => 'name',
			2 => 'description',
			3 => 'folder_id',
			4 => 'created_at',
			5 => 'action'
		);

		$totalData = Document::count();
		$limit = $request->input('length');
		$start = $request->input('start');
		$order = $columns[$request->input('order.0.column')];
		$dir = $request->input('order.0.dir');

		if(empty($request->input('search.value'))){
			$users = Document::offset($start)
				->limit($limit)
				->orderBy($order,$dir)
				->get();
			$totalFiltered = Document::count();
		}else{
			$search = $request->input('search.value');
			$users = Document::where([
				['name', 'like', "%{$search}%"],
			])
				->orWhere('description','like',"%{$search}%")
				->orWhere('created_at','like',"%{$search}%")
				->offset($start)
				->limit($limit)
				->orderBy($order, $dir)
				->get();
			$totalFiltered = Document::where([
				['name', 'like', "%{$search}%"],
			])
				->orWhere('name', 'like', "%{$search}%")
				->orWhere('description','like',"%{$search}%")
				->orWhere('created_at','like',"%{$search}%")
				->count();
		}


		$data = array();

		if($users){
			foreach($users as $r){
				$edit_url = route('documents.edit',$r->id);
				$show_url = asset("uploads/$r->document");
				$nestedData['id'] = '<td><label class="checkbox checkbox-outline checkbox-success"><input type="checkbox" name="documents[]" value="'.$r->id.'"><span></span></label></td>';
				$nestedData['name'] = $r->name;
				$nestedData['description'] = $r->description;
				$nestedData['folder'] = '<span class="label label-lg font-weight-bold  label-light-info label-inline">'.$r->folder->name  .'</span>';


				$nestedData['created_at'] = date('d-m-Y',strtotime($r->created_at));
				$nestedData['action'] = '
                                <div>
                                <td>
                                    <a class="btn btn-sm btn-clean btn-icon" target="_blank" title="Show PDF " href="'.$show_url.'">
                                        <i class="icon-1x text-dark-50 fa fa-file-pdf"></i>
                                    </a>
                                    <a title="Edit " class="btn btn-sm btn-clean btn-icon"
                                       href="'.$edit_url.'">
                                       <i class="icon-1x text-dark-50 flaticon-edit"></i>
                                    </a>
                                    <a class="btn btn-sm btn-clean btn-icon" onclick="event.preventDefault();del('.$r->id.');" title="Delete" href="javascript:void(0)">
                                        <i class="icon-1x text-dark-50 flaticon-delete"></i>
                                    </a>
                                </td>
                                </div>
                            ';
				$data[] = $nestedData;
			}
		}

		$json_data = array(
			"draw"			=> intval($request->input('draw')),
			"recordsTotal"	=> intval($totalData),
			"recordsFiltered" => intval($totalFiltered),
			"data"			=> $data
		);

		echo json_encode($json_data);

	}
    public function create()
    {
	    $title = 'Add New Folder';
	    $folders = Folder::all();
	    return view('admin.documents.create',[ 'folders' => $folders],compact('title'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
	    $this->validate($request, [
		    'name' => 'required|max:255',
		    'folder' => 'required|max:255',
		    'description' => 'required|max:255',
		    'document' => 'required',
	    ]);

	    $input = $request->all();
	    $user = new Document();
	    $user->name = $input['name'];
	    $user->folder_id = $input['folder'];
	    $user->description = $input['description'];
        if ($request->hasFile('document')) {
            if ($request->file('document')->isValid()) {
                $this->validate($request, [
                    'document' => 'required|mimes:jpeg,png,jpg,zip,pdf'
                ]);
                $file = $request->file('document');
                $destinationPath = public_path('/uploads');
                //$extension = $file->getClientOriginalExtension('logo');
                $image = $file->getClientOriginalName('document');
                $image = rand().$image;
                $request->file('document')->move($destinationPath, $image);
                $user->document = $image;

            }
        }
	    $user->save();

	    Session::flash('success_message', 'Great! Document has been saved successfully!');
	    $user->save();
	    return redirect()->back();
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
	    $user = Document::find($id);
	    return view('admin.documents.single', ['title' => 'Folder detail', 'user' => $user]);
    }
	public function showDocument($id)
    {
		// dd($id);
	    $user = Document::find($id);
		// dd($user);
		if($user){
		return response()->json(['status' => true, 'user' => $user]);
		}else{
			return response()->json(['status' => false]);

		}
	    // return view('admin.documents.single', ['title' => 'Folder detail', 'user' => $user]);
    }

	public function detail(Request $request)
	{

		$user = Document::findOrFail($request->id);
		return view('admin.documents.detail', ['title' => 'Folder Detail', 'user' => $user]);
	}

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
	    $user = Document::find($id);
        $folders = Folder::all();
	    return view('admin.documents.edit', ['title' => 'Edit Folder details','folders' => $folders])->withUser($user);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
	    $user = Document::find($id);
	    $this->validate($request, [
		    'name' => 'required|max:255',
		    'folder' => 'required|max:255',
		    'description' => 'required',
	    ]);
	    $input = $request->all();

	    $user->name = $input['name'];
        $user->folder_id = $input['folder'];
        $user->description = $input['description'];
        if ($request->hasFile('document')) {
            if ($request->file('document')->isValid()) {
                $this->validate($request, [
                    'document' => 'required|mimes:jpeg,png,jpg,zip,pdf'
                ]);
                $file = $request->file('document');
                $destinationPath = public_path('/uploads');
                //$extension = $file->getClientOriginalExtension('logo');
                $image = $file->getClientOriginalName('document');
                $image = rand().$image;
                $request->file('document')->move($destinationPath, $image);
                $user->document = $image;

            }
        }
	    $user->save();

	    Session::flash('success_message', 'Great! Document successfully updated!');
	    return redirect()->back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
		// dd($id);
	    $user = Document::find($id);
		if($user)
		{
		    $user->delete();
			return response()->json(['status' => true, 'msg' => 'Document has been deleted']);

		}else{
			return response()->json(['status' => false, 'msg' => 'Document has been deleted']);

		}
	    return redirect()->route('documents.index');

    }
	public function deleteSelected(Request $request)
	{
		$input = $request->all();
		$this->validate($request, [
			'documents' => 'required',

		]);
		foreach ($input['documents'] as $index => $id) {

			$user = Document::find($id);
				$user->delete();

		}
		Session::flash('success_message', 'Document successfully deleted!');
		return redirect()->back();

	}
}
