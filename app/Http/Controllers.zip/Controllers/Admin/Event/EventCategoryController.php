<?php

namespace App\Http\Controllers\Admin\Event;

use App\Http\Controllers\Controller;
use App\Models\EventCategory;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Str;

class EventCategoryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\Contracts\View\View
     */
    public function index()
    {
        return view('admin.event_categories.index', ['title' => 'Event Categories']);

    }
    public function getEventCategories(Request $request)
    {
        $columns = array(
            0 => 'id',
            1 => 'name',
            2 => 'slug',
            3 => 'created_at',
            4 => 'action',
        );
        $totalData = EventCategory::count();
        $limit = $request->input('length');
        $start = $request->input('start');
        $order = $columns[$request->input('order.0.column')];
        $dir = $request->input('order.0.dir');
        if (empty($request->input('search.value'))) {
            $event_categories = EventCategory::offset($start)
                ->limit($limit)
                ->orderBy($order, $dir)
                ->get();
            $totalFiltered = EventCategory::count();
        } else {
            $search = $request->input('search.value');
            $event_categories = EventCategory::where('name', 'like', "%{$search}%")
                ->orWhere('slug', 'like', "%{$search}%")
                ->orWhere('created_at', 'like', "%{$search}%")
                ->offset($start)
                ->limit($limit)
                ->orderBy($order, $dir)
                ->get();
            $totalFiltered = EventCategory::where('name', 'like', "%{$search}%")
                ->orWhere('slug', 'like', "%{$search}%")
                ->count();
        }
        $data = array();
        if ($event_categories) {
            foreach ($event_categories as $r) {
                $edit_url = route('event-categories.edit', $r->id);
                $nestedData['id'] = '<td><label class="checkbox checkbox-outline checkbox-success"><input type="checkbox" name="categories[]" value="' . $r->id . '"><span></span></label></td>';
                $nestedData['name'] = $r->name;
                $nestedData['slug'] = $r->slug;
                $nestedData['created_at'] = date('Y-m-d h:m:s a', strtotime($r->created_at));
                $nestedData['updated_at'] = date('Y-m-d h:m:s a', strtotime($r->updated_at));
                $nestedData['action'] = '
                          <div>
                                <td>
                                    <a class="btn btn-sm btn-clean btn-icon" onclick="event.preventDefault();viewInfo(' . $r->id . ');" title="View Event Category" href="javascript:void(0)">
                                        <i class="icon-1x text-dark-50 flaticon-eye"></i>
                                    </a>
                                    <a title="Edit Event Category" class="btn btn-sm btn-clean btn-icon"
                                       href="' . $edit_url . '">
                                       <i class="icon-1x text-dark-50 flaticon-edit"></i>
                                    </a>
                                    <a class="btn btn-sm btn-clean btn-icon" onclick="event.preventDefault();del(' . $r->id . ');" title="Delete Event Category" href="javascript:void(0)">
                                        <i class="icon-1x text-dark-50 flaticon-delete"></i>
                                    </a>
                                </td>
                                </div>
                            ';
                $data[] = $nestedData;
            }
        }

        $json_data = array(
            "draw" => intval($request->input('draw')),
            "recordsTotal" => intval($totalData),
            "recordsFiltered" => intval($totalFiltered),
            "data" => $data
        );

        echo json_encode($json_data);
    }
    public function getEventCategory(Request $request)
    {
        $event_category = EventCategory::findOrFail($request->input('id'));
        return view('admin.event_categories.detail', ['title' => 'Show EventCategory', 'event_category' => $event_category]);
    }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\Contracts\View\View
     */
    public function create()
    {
       return view('admin.event_categories.create', ['title' => 'Create EventCategory']);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validatedData = $this->validate($request, [
            'name' => 'required|min:3|max:255|string',
        ]);
        $validatedData['slug'] = $this->createSlug($request->input('name'), 0);
        EventCategory::create($validatedData);
        Session::flash('success_message', 'Success! Category has been updated successfully!');
        return redirect()->back();
    }
    public function createSlug($title, $id)
    {
        $slug = Str::slug($title);
        $allSlugs = $this->getRelatedSlugs($slug, $id);
        for ($i = 1; $i <= 10; $i++) {
            $newSlug = $slug . '-' . $i;
            if (!$allSlugs->contains('slug', $newSlug)) {
                return $newSlug;
            }
        }
        throw new\Excprion('Can not create a unique slug');
    }

    protected function getRelatedSlugs($slug, $id)
    {
        return EventCategory::select('slug')->where('slug', 'like', $slug . '%')
            ->where('id', '<>', $id)
            ->get();
    }
    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\Contracts\View\View
     */
    public function show($id)
    {
        $event_category = EventCategory::findOrFail($id);
        return view('admin.event_categories.show', ['title' => 'Show EventCategory', 'event_category' => $event_category]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\Contracts\View\View
     */
    public function edit($id)
    {
        $event_category = EventCategory::findOrFail($id);

        return view('admin.event_categories.edit', ['title' => 'Edit EventCategory', 'event_category' => $event_category]);

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function update(Request $request, $id)
    {
        $event_category = EventCategory::findOrFail($id);


        $event_category['name'] =$request->input('name');
        $event_category['slug'] = $this->createSlug($request->input('name'), 0);
//            dd($category);
        $event_category->save();
        Session::flash('success_message', 'Success! Category has been updated successfully!');
        return redirect()->back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function destroy($id)
    {
        $event_category = EventCategory::findOrFail($id);
        $event_category->delete();
        Session::flash('success_message', 'Success! Category deleted');
        return redirect()->back();
    }
    public function DeleteSelectedEventCategory(Request $request)
    {
        $input = $request->all();
        $this->validate($request, [
            'event_categories' => 'required',
        ]);
        foreach ($input['event_categories'] as $index => $id) {

            $event_category = EventCategory::find($id);
            $event_category->delete();
        }
        Session::flash('success_message', 'successfully deleted!');
        return redirect()->back();
    }
}
