<?php

namespace App\Http\Controllers\Admin\Event;

use App\Http\Controllers\Controller;
use App\Mail\eventMail;
use App\Models\Event;
use App\Models\EventCategory;
use App\Models\Setting;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Mail;
use Webpatser\Uuid\Uuid;
use Illuminate\Support\Facades\Session;


class EventController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\Contracts\View\View
     */
    public function index()
    {
        $events = Event::all();
        return view('admin.events.index', ['title' => 'Events', 'events' => $events]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\Contracts\View\View
     */
    public function create()
    {
       /* $user = Auth::user();
        $id = $user->id;
        $name = $user->name;`
        dd($user);*/
        $event_categories = EventCategory::all();
        $users = User::all();
//  dd($users);
        return view('admin.events.create', ['title' => 'Create Events', 'event_categories' => $event_categories, 'users' => $users]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function store(Request $request)
    {
        //  dd($request->all());
        $validatedData = $this->validate($request, [
            'title' => 'required',
            'narrative' => 'required',
            'start_time' => 'required',
            'end_time' => 'required',
        
         //  'event_category_id' => 'required',
        ]);

         $id = $request->user_id;
        $user = Auth::user();
        $validatedData['uuid'] = (string)Uuid::generate();
        $stime =strtotime( $request->start_time);
         $validatedData['start_time']= date("Y-m-d H:i:s", $stime);

         $etime =strtotime( $request->end_time);
         $validatedData['end_time']= date("Y-m-d H:i:s", $etime);
        $validatedData['created_by'] = $user->id;
        $validatedData['event_file']= $request->input('event_file');
//        dd($validatedData);
        $event = Event::create($validatedData);
      if($id){
        $notify_user = User::find($id);
        // dd($notify_user);
      
        $email = $notify_user->email;
      }
        /*Send Email*/
            $settings = Setting::pluck('value', 'name')->all();
           if ($event->user){
               $data = array(
                   'name' => $event->user->name,
                   'user_email' => $event->user->email,
                   'subject' => "Project Status Updated ",
                   'msg' => "Your Project ($event->title) Event Add ",
                   'email' => isset($settings['email']) ? $settings['email'] : 'james@inetventures.co.uk',
                   'logo' => isset($settings['admin_logo']) ? $settings['admin_logo'] : '',
                   'site_title' => isset($settings['site_title']) ? $settings['site_title'] : 'iNet Ventures',
                   'notify_user' => $email,

               );
            //    $data1 = array(
            //     'name' => $event->user->name,
            //      'user_email' => $notify_user->email,
            //     'subject' => "Project Status Updated ",
            //     'msg' => "Your Project ($event->title) Event Add ",
            //     'email' => isset($settings['email']) ? $settings['email'] : 'james@inetventures.co.uk',
            //     'logo' => isset($settings['admin_logo']) ? $settings['admin_logo'] : '',
            //     'site_title' => isset($settings['site_title']) ? $settings['site_title'] : 'iNet Ventures',
            // );

            Mail::to($data['user_email'],$data['notify_user'])->send(new eventMail($data));
            // Mail::to($data1['email'])->send(new eventMail($data1));

            //    Mail::send('emails.event-mail', $data, function ($message) use ($data) {
            //        $message->to($data['user_email'], '')
            //            ->from($data['email'], $data['site_title'])
            //            ->subject('Project Status Updated ');
            //    });
            //    Mail::send('emails.event-mail', $data1, function ($message) use ($data1) {
            //     $message->to($data1['user_email'], '')
            //         ->from($data1['email'], $data1['site_title'])
            //         ->subject('Project Status Updated ');
            // });
           }


        Session::flash('success_message', 'Success! Event has been created successfully!');
        return redirect()->route("events.index");
    }
    public function saveEventFiles(Request $request)
    {

        $image = $request->file('file');
        //$imageName = time() . $image->getClientOriginalName();
        $imageName = $image->getClientOriginalName();
//        $imageName = time().$imageName;
        $image->move('uploads/', $imageName);
        $id  = $this->clean($imageName);
        return response()->json(['imageName' => $imageName,'id'=>$id]);
    }
    public function deleteImage($id){
        $name = explode('.',$id);
        $delete_old_file="uploads/".$id;
        File::delete($delete_old_file);
        $id  = $this->clean($id);
        return response()->json(['id' =>$id]);
    }
    public function  clean($string) {
        $string = str_replace(' ', '-', $string); // Replaces all spaces with hyphens.

        return preg_replace('[^A-Za-z0-9-]', '', $string); // Removes special chars.
    }
    public function download($uuid)
    {
        $event = Event::where('uuid', $uuid)->firstOrFail();
        $pathToFile = public_path('uploads/' . $event->event_file);
        return response()->download($pathToFile);
    }
    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\Contracts\View\View
     */
    public function show($id)
    {
        $events = Event::findOrFail($id);
        return view('admin.events.detail', ['title' => 'show event', 'events' => $events]);
    }
    public function eventDetail(Request $request)
    {
    //  dd($request->all());
        $event = Event::where("id",$request->id)->with('event_category','user')->first();
    
        return view('admin.events.show', ['title' => 'event Detail', 'event' => $event]);
    }
    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\Contracts\View\View
     */
    public function edit($id)
    {
        $events = Event::findOrFail($id);
        $event_categories = EventCategory::all();
        $users = User::all();
//  dd($users);
        return view('admin.events.edit', ['title' => 'Edit Events', 'event_categories' => $event_categories, 'users' => $users, 'events' => $events]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function update(Request $request, $id)
    {
        $events = Event::findOrFail($id);

        $input = $request->all();
        $events['title'] =$request->input('title');
        $events['narrative'] =$request->input('narrative');
        $stime =strtotime($request->input('start_time'));
        $events['start_time'] =date("Y-m-d H:i:s", $stime);
       
        $etime =strtotime($request->input('end_time'));
        $events['end_time'] =date("Y-m-d H:i:s", $etime);
        $events['event_category_id'] =$request->input('event_category_id');
        $events['user_id'] =$request->input('user_id');
        if ($request->event_file){
            $events['event_file'] = $request->input('event_file');

        }
        $events->save();
        Session::flash('success_message', 'Success! Event has been updated successfully!');
        return redirect()->back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $events = Event::findOrFail($id);
        $events->delete();
        Session::flash('success_message', 'Success! Event has been deleted successfully!');
        return redirect()->route("events.index");
    }
}
