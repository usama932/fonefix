<?php

    namespace App\Http\Controllers\Admin\Article;

    use App\Http\Controllers\Controller;
    use App\Models\Category;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\Auth;
    use Illuminate\Support\Facades\Session;
    use Illuminate\Support\Str;
    use phpDocumentor\Reflection\DocBlockFactory;

    class ArticleCategoriesController extends Controller
    {
        /**
         * Display a listing of the resource.
         *
         * @return \Illuminate\Http\Response
         */
        private $obj_category;

        public function __construct(Category $categoryObject)
        {

            $this->obj_category = $categoryObject;
        }

        public function index()
        {
            $categories = Category::with('children')->whereNull('parent_id')->get();

            return view('admin.categories.index', ['title' => 'Category List'])->with([
                'categories' => $categories
            ]);
        }

        public function getCategories(Request $request)
        {
            $columns = array(
                0 => 'id',
                1 => 'name',
                2 => 'slug',
                3 => 'parent',
                4 => 'created_at',
                7 => 'action',
            );
            $totalData = Category::count();
            $limit = $request->input('length');
            $start = $request->input('start');
            $order = $columns[$request->input('order.0.column')];
            $dir = $request->input('order.0.dir');
            if (empty($request->input('search.value'))) {
                $categories = Category::offset($start)
                    ->limit($limit)
                    ->orderBy($order, $dir)
                    ->get();
                $totalFiltered = Category::count();
            } else {
                $search = $request->input('search.value');
                $categories = Category::where('name', 'like', "%{$search}%")
                    ->orWhere('slug', 'like', "%{$search}%")
                    ->orWhere('parent_id', 'like', "%{$search}%")
                    ->orWhere('created_at', 'like', "%{$search}%")
                    ->offset($start)
                    ->limit($limit)
                    ->orderBy($order, $dir)
                    ->get();
                $totalFiltered = Category::where('name', 'like', "%{$search}%")
                    ->orWhere('slug', 'like', "%{$search}%")
                    ->orWhere('parent', 'like', "%{$search}%")
                    ->count();
            }
            $data = array();
            if ($categories) {
                foreach ($categories as $r) {
                    $edit_url = route('categories.edit', $r->id);
                    $nestedData['id'] = '<td><label class="checkbox checkbox-outline checkbox-success"><input type="checkbox" name="categories[]" value="' . $r->id . '"><span></span></label></td>';
                    $nestedData['name'] = $r->name;
                    $nestedData['slug'] = $r->slug;
                    if ($r->parent_id == null) {
                        $nestedData['parent_id'] = '<span class="label label-lg font-weight-bold  label-light-info label-inline">Main Category</span>';
                    } else {
                        $nestedData['parent_id'] = $r->parent->name;

                    }
                    $nestedData['created_at'] = date('Y-m-d h:m:s a', strtotime($r->created_at));
                    $nestedData['updated_at'] = date('Y-m-d h:m:s a', strtotime($r->updated_at));
                    $nestedData['action'] = '
                          <div>
                                <td>
                                    <a class="btn btn-sm btn-clean btn-icon" onclick="event.preventDefault();viewInfo(' . $r->id . ');" title="View user" href="javascript:void(0)">
                                        <i class="icon-1x text-dark-50 flaticon-eye"></i>
                                    </a>
                                    <a title="Edit Category" class="btn btn-sm btn-clean btn-icon"
                                       href="' . $edit_url . '">
                                       <i class="icon-1x text-dark-50 flaticon-edit"></i>
                                    </a>
                                    <a class="btn btn-sm btn-clean btn-icon" onclick="event.preventDefault();del(' . $r->id . ');" title="Delete user" href="javascript:void(0)">
                                        <i class="icon-1x text-dark-50 flaticon-delete"></i>
                                    </a>
                                </td>
                                </div>
                            ';
                    $data[] = $nestedData;
                }
            }

            $json_data = array(
                "draw" => intval($request->input('draw')),
                "recordsTotal" => intval($totalData),
                "recordsFiltered" => intval($totalFiltered),
                "data" => $data
            );

            echo json_encode($json_data);
        }

        public function getCategory(Request $request)
        {
            $category = Category::findOrFail($request->input('id'));
            return view('admin.articles.single', ['title' => 'Show Category', 'category' => $category]);
        }

        /**
         * Show the form for creating a new resource.
         *
         * @return \Illuminate\Contracts\View\Factory|\Illuminate\Contracts\View\View
         */
        public function create()
        {
            $categories = Category::with('children')->whereNull('parent_id')->get();
            return view('admin.categories.create', ['title' => 'Create Category', 'categories' => $categories]);
        }

        /**
         * Store a newly created resource in storage.
         *
         * @param \Illuminate\Http\Request $request
         * @return \Illuminate\Http\RedirectResponse
         */
        public function store(Request $request)
        {
            $validatedData = $this->validate($request, [
                'name' => 'required|min:3|max:255|string',
                'parent_id' => 'sometimes|nullable|numeric'
            ]);
            $validatedData['slug'] = $this->createSlug($request->input('name'), 0);
            Category::create($validatedData);
            Session::flash('success_message', 'Success! Category has been updated successfully!');
            return redirect()->back();
        }

        public function createSlug($title, $id)
        {
            $slug = Str::slug($title);
            $allSlugs = $this->getRelatedSlugs($slug, $id);
            for ($i = 1; $i <= 10; $i++) {
                $newSlug = $slug . '-' . $i;
                if (!$allSlugs->contains('slug', $newSlug)) {
                    return $newSlug;
                }
            }
            throw new\Excprion('Can not create a unique slug');
        }

        protected function getRelatedSlugs($slug, $id)
        {
            return Category::select('slug')->where('slug', 'like', $slug . '%')
                ->where('id', '<>', $id)
                ->get();
        }

        /**
         * Display the specified resource.
         *
         * @param int $id
         * @return \Illuminate\Contracts\View\Factory|\Illuminate\Contracts\View\View
         */
        public function show($id)
        {
            $category = Category::findOrFail($id);
            return view('admin.categories.show', ['title' => 'Show Category', 'categories' => $category]);

        }

        /**
         * Show the form for editing the specified resource.
         *
         * @param int $id
         * @return \Illuminate\Contracts\View\Factory|\Illuminate\Contracts\View\View
         */
        public function edit($id)
        {
            $category = Category::findOrFail($id);
            $categories = Category::with('children')->whereNull('parent_id')->get();

            /*$category = Category::findOrFail($id);*/
            return view('admin.categories.edit', ['title' => 'Edit Category', 'category' => $category, 'categories' => $categories]);

        }

        /**
         * Update the specified resource in storage.
         *
         * @param \Illuminate\Http\Request $request
         * @param int $id
         * @return \Illuminate\Http\RedirectResponse
         */
        public function update(Request $request, $id)
        {
            $category = Category::findOrFail($id);

            $category['name'] = $request->input('name');
            $category['slug'] = $this->createSlug($request->input('name'), 0);
//            dd($category);
            $category->save();
            Session::flash('success_message', 'Success! Category has been updated successfully!');
            return redirect()->back();
        }

        /**
         * Remove the specified resource from storage.
         *
         * @param int $id
         * @return \Illuminate\Http\RedirectResponse
         */
        public function destroy($id)
        {
            $category = Category::findOrFail($id);
            if ($category->children) {
                foreach ($category->children()->with('article')->get() as $child) {
                    foreach ($child->article as $article) {
                        $article->delete();
//                        $article->update(['category_id' => NULL]);
                    }
                }

                $category->children()->delete();
            }
            if ($category->article) {
                foreach ($category->article as $article) {
                    $article->delete();
//                $article->update(['category_id' => NULL]);
                }
            }
            $category->delete();
            /*$category = Category::findOrFail($id);
            if ($category->children) {
                $category->children()->delete();
            }
            $category->delete();*/
            Session::flash('success_message', 'Success! Category deleted');
            return redirect()->route('categories.index');
        }

        public function DeleteSelectedCategory(Request $request)
        {
            $input = $request->all();
            $this->validate($request, ['category_id' => 'required',]);
            foreach ($input['category_id'] as $key => $val) {
                /*Category::findOrFail($val)->delete();*/
                $category = Category::findOrFail($val);
                if ($category->children) {
                    $category->children()->delete();
                }
                $category->delete();
            }
            Session::flash('success_message', 'Categories successfully deleted');
            return redirect()->back();
        }
    }
