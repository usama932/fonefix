<?php

    namespace App\Http\Controllers\Admin\Article;

    use App\Http\Controllers\Controller;
use App\Mail\shareArticle;
use App\Models\Count;
    use App\Models\User;
    use App\Models\Article;
    use App\Models\ArticleImage;
    use App\Models\Category;
    use Illuminate\Http\Request;
    use Illuminate\Support\Carbon;
    use Illuminate\Support\Facades\Auth;
    use Illuminate\Support\Facades\Mail;
    use Illuminate\Support\Facades\Session;
    use Illuminate\Support\Str;
    use File;
use Spatie\Permission\Models\Role;

class ArticlesController extends Controller
    {
        /**
         * Display a listing of the resource.
         *
         * @return \Illuminate\Http\Response
         */
        private $obj_category;
        private $obj_article;

        public function __construct(Category $categoryObject, Article $articleObject)
        {

            $this->obj_category = $categoryObject;
            $this->obj_article = $articleObject;
        }

        public function index()
        {
            $articles= Article::orderBy('updated_at', 'DESC')->orderBy('created_at', 'DESC')->paginate(20);

            return view('admin.articles.index3', ['title' => 'Articles', 'articles'=> $articles]);
        }

        public function getArticles(Request $request)
        {
            $columns = array(
                0 => 'id',
                1 => 'title',
                2 => 'author',
                3 => 'category',
                4 => 'priority',
                5 => 'created_at',
                6 => 'updated_at',
                7 => 'action'
            );

            $totalData = Article::count();
            $limit = $request->input('length');
            $start = $request->input('start');
            $order = $columns[$request->input('order.0.column')];
            $dir = $request->input('order.0.dir');

            if (empty($request->input('search.value'))) {
                $articles = Article::offset($start)
                    ->limit($limit)
                    ->orderBy($order, $dir)
                    ->get();
                $totalFiltered = Article::count();
            } else {
                $search = $request->input('search.value');
                $articles = Article::where('title', 'like', "%{$search}%")
                    ->offset($start)
                    ->limit($limit)
                    ->orderBy($order, $dir)
                    ->get();
                $totalFiltered = Article::where('title', 'like', "%{$search}%")
                    ->count();
            }


            $data = array();

            if ($articles) {
                foreach ($articles as $r) {
                    $edit_url = route('articles.edit', $r->id);
                    $nestedData['id'] = '<td><label class="checkbox checkbox-outline checkbox-success"><input type="checkbox" name="categories[]" value="'.$r->id.'"><span></span></label></td>';
                    $nestedData['title'] = $r->title;
                    $nestedData['author'] = $r->user->name;
                    if ($r->priority == 1) {
                        $nestedData['priority'] = '<span class="label label-lg font-weight-bold  label-light-info label-inline">Active</span>';
                    } else {
                        /*label label-danger label-inline mr-2*/
                        $nestedData['priority'] = '<span class="label label-lg font-weight-bold  label-light-danger label-inline">Inactive</span>';
                    }
                    if($r->categories){
                    $nestedData['category'] = $r->categories->name;
                    }else{
                        $nestedData['category'] = '<span class="label label-lg font-weight-bold  label-light-danger label-inline">Not Categorised</span>';
                    }
                    $nestedData['created_at'] = date('Y-m-d h:m:s a', strtotime($r->created_at));
                    $nestedData['updated_at'] = date('Y-m-d h:m:s a', strtotime($r->updated_at));
                    $nestedData['action'] = '
                                <div>
                                <td>
                                    <a class="btn btn-sm btn-clean btn-icon" onclick="event.preventDefault();viewInfo('.$r->id.');" title="View Article" href="javascript:void(0)">
                                        <i class="icon-1x text-dark-50 flaticon-eye"></i>
                                    </a>
                                    <a title="Edit Article" class="btn btn-sm btn-clean btn-icon"
                                       href="'.$edit_url.'">
                                       <i class="icon-1x text-dark-50 flaticon-edit"></i>
                                    </a>
                                    <a class="btn btn-sm btn-clean btn-icon" onclick="event.preventDefault();del('.$r->id.');" title="Delete Article" href="javascript:void(0)">
                                        <i class="icon-1x text-dark-50 flaticon-delete"></i>
                                    </a>
                                </td>
                                </div>
                            ';

				$data[] = $nestedData;
			}
		}

		$json_data = array(
			"draw"			=> intval($request->input('draw')),
			"recordsTotal"	=> intval($totalData),
			"recordsFiltered" => intval($totalFiltered),
			"data"			=> $data
		);

		echo json_encode($json_data);

        }

        public function search(Request $request)
        {
            //get the general information about the website
            /*$website = General::query()->firstOrFail();*/

            $key = trim($request->q);

            $articles = Article::query()
                ->where('title', 'like', "%{$key}%")
                ->orWhere('content', 'like', "%{$key}%")
                ->orWhere('case_number', 'like', "%{$key}%")
                ->orderBy('updated_at', 'DESC')
                ->orderBy('created_at', 'desc')
                ->get();

            //get all the categories
            $categories = Category::all();


            //get the recent 5 posts
            /*$recent_posts = Article::query()
                ->where('is_published', true)
                ->orderBy('created_at', 'desc')
                ->take(5)
                ->get();*/

            return view('admin.articles.search', [
                'key' => $key,
                'title' => 'Search of'.$key,
                'articles' => $articles,
                'categories' => $categories,
            ]);
        }
        public function PriorityOne()
        {
            $articles_priority= Article::where('priority',1)->orderBy('updated_at', 'DESC')->orderBy('created_at', 'DESC')->get();

            return view('admin.articles.priority', ['title' => 'Priority One Articles', 'articles_priority'=> $articles_priority]);
        }

        public function getArticle(Request $request)
        {
            $article = Article::findOrFail($request->input('id'));
            return view('admin.articles.single', ['title' => 'Edit Article', 'article' => $article]);
        }

        /**
         * Show the form for creating a new resource.
         *
         * @return \Illuminate\Contracts\View\Factory|\Illuminate\Contracts\View\View
         */
        public function create()
        {
            $categories = Category::with('children')->whereNull('parent_id')->get();
            return view('admin.articles.create', ['title' => 'Create Article', 'categories' => $categories]);
        }
        public function subCategory(Request $request)
        {
            $category_id = $request->id;
            $categories = Category::where('parent_id',$category_id)->get();
           
            return view('admin.articles.subCategory', ['categories' => $categories]);
        }



        /**
         * Store a newly created resource in storage.
         *
         * @param \Illuminate\Http\Request $request
         * @return \Illuminate\Http\RedirectResponse
         */
        public function store(Request $request)
        {
        //    dd($request->all());
            $validatedData = $this->validate($request, [
                'title' => 'required|min:3|max:255',
                'content' => 'required',
                'case_number' ,
                'subcategory_id' => 'required|numeric',
               
            ]);
            /*dd($validatedData);*/
            $input = $request->all();
            $validatedData['user_id'] = Auth::id();
            $validatedData['category_id'] = $request->input('subcategory_id');
            $validatedData['slug'] = $this->createSlug($request->input('title'), 0);
            $priority = $request->input('priority');

            if ($priority == null) {
                $priority = 0;
            } else {
                $priority = 1;
            }
            $validatedData['priority'] = $priority;
            $article = Article::create($validatedData);
            if(array_key_exists('uploadedImages', $input)){
                foreach ($request->uploadedImages as $key => $picture) {
                    $articleImage = new ArticleImage();
                    $articleImage->article_id = $article->id;
                    $articleImage->image = $picture;
                    $articleImage->type = 1;
                    $articleImage->save();
                }
            }


            $articles = Article::all();
            $details = [
                'title' => 'Mail from ItSolutionStuff.com',
                'body' => 'This is for testing email using smtp'
            ];

             Mail::to('your_receiver_email@gmail.com')->send(new \App\Mail\ArticleCreateMail($article));

            Session::flash('success_message', 'Success! Article has been Posted  successfully!');
            return redirect()->back();

        }

        public function createSlug($title, $id)
        {
            $slug = Str::slug($title);
            $allSlugs = $this->getRelatedSlugs($slug, $id);
            for ($i = 1; $i <= 10; $i++) {
                $newSlug = $slug . '-' . $i;
                if (!$allSlugs->contains('slug', $newSlug)) {
                    return $newSlug;
                }
            }
            throw new\Excprion('Can not create a unique slug');
        }

        protected function getRelatedSlugs($slug, $id)
        {
            return Article::select('slug')->where('slug', 'like', $slug . '%')
                ->where('id', '<>', $id)
                ->get();
        }
        public function saveArticlesImages(Request $request)
        {
            $image = $request->file('file');
            //$imageName = time() . $image->getClientOriginalName();
            $imageName = $image->getClientOriginalName();
//        $imageName = time().$imageName;
            $image->move('uploads/', $imageName);
            $id  = $this->clean($imageName);
            return response()->json(['imageName' => $imageName,'id'=>$id]);
        }
        public function deleteImage($id){
            $name = explode('.',$id);
            $delete_old_file="uploads".$id;
            File::delete($delete_old_file);
            $id  = $this->clean($id);
            return response()->json(['id' =>$id]);
        }
        public function  clean($string) {
            $string = str_replace(' ', '-', $string); // Replaces all spaces with hyphens.

            return preg_replace('/[^A-Za-z0-9\-]/', '', $string); // Removes special chars.
        }
        public function deleteArticleImage($product_id, $image_id){
            $articleImage =  ArticleImage::where('id',$image_id)->first();
            if ($articleImage)
            {
                $articleImage->delete();
                $delete_old_file="uploads".$articleImage->image;
                File::delete($delete_old_file);
            }
            return redirect()->back()->withSuccess('Stamp image has been deleted successfuly.');
        }

        /**
         * Display the specified resource.
         *
         * @param int $id
         * @return \Illuminate\Contracts\View\Factory|\Illuminate\Contracts\View\View
         */
        public function show($id)
        {

            $article = Article::find($id);
            $categories = Category::orderBy('name', 'asc')->pluck('name', 'id')->toArray();

            $view  = new  Count();
            $view->type  = 2;
            $view->user_id  = Auth::user()->id;
            $view->save();
            return view('admin.articles.single', ['title' => 'Edit Article', 'article' => $article, 'categories' => $categories]);
        }
        public function articleByCat($slug)
        {
             $category = Category::where('slug', $slug)->first();
//            dd($category);
            return view('admin.articles.a_by_cat', compact('category'));
        }
        public function articleByAuthor($name)
        {
             $author = User::where('name', $name)->first();
        //   $articles = $author->articles->count();
        //   dd($articles);
            return view('admin.articles.a_by_author', compact('author'));
        }
        public function articleDetail(Request $request)
        {
            /*dd('working');*/
            $article = Article::findOrFail($request->id)->with('categories','user')->first();
            $categories = Category::orderBy('name', 'asc')->pluck('name', 'id')->toArray();
            return view('admin.articles.show', ['title' => 'Show Article', 'article' => $article, 'categories' => $categories]);
        }
        public function printable(Request $request)
        {
            /*dd('working');*/
            $article = Article::findOrFail($request->id)->with('categories','user')->first();
            $categories = Category::orderBy('name', 'asc')->pluck('name', 'id')->toArray();
            return view('admin.articles.show', ['title' => 'Edit Article', 'article' => $article, 'categories' => $categories]);
        }
        /**
         * Show the form for editing the specified resource.
         *
         * @param int $id
         * @return \Illuminate\Contracts\View\Factory|\Illuminate\Contracts\View\View
         */
        public function edit($id)
        {
            $article = Article::findOrFail($id);
            $categories = Category::with('children')->whereNull('parent_id')->get();
            return view('admin.articles.edit', ['title' => 'Edit Article', 'article' => $article, 'categories' => $categories]);
        }


        public function shareArticle($id)
        {
            // dd($id);
            $roles = Role::all();
            $article = Article::findOrFail($id);
            $categories = Category::with('children')->whereNull('parent_id')->get();
            // dd($categories);
            return view('admin.articles.shareArticle', ['title' => 'share Article','roles' => $roles, 'article' => $article, 'categories' => $categories]);
        }
        public function shareEmail($id)
        {
         $article_id = $id;
            return view('admin.articles.shareEmail',compact('article_id'));

        //    dd($request->all());           
        //    $roles = Role::all();
        //     $article = Article::findOrFail($id);
        //     $categories = Category::with('children')->whereNull('parent_id')->get();
        //     return view('admin.articles.shareArticle', ['title' => 'share Article','roles' => $roles, 'article' => $article, 'categories' => $categories]);
        }
        public function sendShareEmail(Request $request)
        {
         $id = $request->articleid;
         $email = $request->email;
         $articles= Article::find($id);
        //  dd($articles);
         $data = array(
            'title' => $articles->title,
            'name' => $articles->user->name,
            'article_id' => $articles->id,
             'author' => $articles->user->name,
            'content' => $articles->content,
            'category'=> $articles->categories->name,
            'created_at' => $articles->created_at,
            'mail' => $email
        );
        Mail::to($data['mail'])->send(new shareArticle($data));

        Session::flash('success_message', 'Success! Article has been Shared successfully!');

        return redirect()->back();

        //    dd($request->all());           
        //    $roles = Role::all();
        //     $article = Article::findOrFail($id);
        //     $categories = Category::with('children')->whereNull('parent_id')->get();
        //     return view('admin.articles.shareArticle', ['title' => 'share Article','roles' => $roles, 'article' => $article, 'categories' => $categories]);
        }
        public function shareUsers(Request $request)
        {
            // dd($request->all());
         $role = $request->role;  
         $id = $request->articleid;
        //  dd($id);
         $articles = Article::find($id);
        //  dd($articles);
            $users = User::where('role',$role)->get();
            foreach($users as $user){
                $emails[] = $user->email;
            }
            // dd($users);
            $data = array(
                'title' => $articles->title,
                'name' => $articles->user->name,
                'article_id' => $articles->id,
                 'author' => $articles->user->name,
                'content' => $articles->content,
                'category'=> $articles->categories->name,
                'created_at' => $articles->created_at,
                'email' => $emails,
               
                'site_title' => isset($settings['site_title']) ? $settings['site_title'] : 'iNet Ventures',
            );
            Mail::to($data['email'])->send(new shareArticle($data));
            Session::flash('success_message', 'Success! Article has been Shared successfully!');

            return redirect()->back();

            // return response()->json(['status' => true,'user' => $user]);
        }
        /**
         * Update the specified resource in storage.
         *
         * @param \Illuminate\Http\Request $request
         * @param int $id
         * @return \Illuminate\Http\RedirectResponse
         */
        public function update(Request $request, $id)
        {
            $article = Article::findOrFail($id);
            if (Auth::user()->id == $article->user_id or Auth::user()->role == 1 or Auth::user()->role == 3){
                $input = $request->all();
                $article['user_id'] = Auth::id();
                $article['title'] = $request->input('title');
                $article['content'] = $request->input('content');
                $article['case_number'] = $request->input('case_number');
                $article['slug'] = $this->createSlug($request->input('title'), 0);
                $priority = $request->input('priority');
                if ($priority == null) {
                    $priority = 0;
                } else {
                    $priority = 1;
                }
                $article['priority'] = $priority;
                $article->save();
                if (array_key_exists('uploadedImages', $input)) {
                    foreach ($request->uploadedImages as $key => $picture) {
                        $articleImage = new ArticleImage();
                        $articleImage->article_id = $article->id;
                        $articleImage->image = $picture;
                        $articleImage->type = 1;
                        $articleImage->save();
                    }
                }
                Session::flash('success_message', 'Success! Article Category has been updated successfully!');
            }else{
                Session::flash('error_message', 'Sorry! You dont have right to Edit this Article!');
            }
            return redirect()->back();
            /*if ($request->hasFile('image')) {
              if ($request->file('image')->isValid()) {
                  $this->validate($request, [
                      'image' => 'required|image|mimes:jpeg,png,jpg'
                  ]);
                  $file = $request->file('image');
                  $destinationPath = "storage/article";
                  $extension = $file->getClientOriginalExtension('image');
                  $fileName = $file->getClientOriginalName('image');
                  $fileName = time() . $fileName;
                  //renameing image
                  $request->file('image')->move($destinationPath, $fileName);
                  $delete_old_file = "storage/article/" . $article->image;
                  File::delete($delete_old_file);
                  $article->image = $fileName;
              }
          }*/
        }

        /**
         * Remove the specified resource from storage.
         *
         * @param int $id
         * @return \Illuminate\Http\Response
         */
        public function destroy($id)
        {
           
            $article = Article::findOrFail($id);

            if (Auth::user()->id == $article->user_id or Auth::user()->role == 1 or Auth::user()->role == 3){
                $article->delete();
                return response()->json(['status' => true, 'msg' => 'Article has been deleted']);

            }else{
                return response()->json(['status' => false, 'msg' => 'Article has  not Found']);

            }

        }

        public function DeleteSelectedArticle(Request $request)
        {
            if (Auth::user()->role == 1) {
                $this->validate($request, [
                    'post' => 'required',
                ]);

                foreach ($request->input('post') as $index => $article_id) {
                    $article = Article::findOrFail($article_id);
                    $article->categories()->detach();
                    $article->delete();
                }
                Session::flash('success_message', 'Success! Article successfully deleted!');
            }else{
                Session::flash('error_message', 'Sorry! only Admin can Delete Articles!');
            }
            return redirect()->back();

        }
    }
