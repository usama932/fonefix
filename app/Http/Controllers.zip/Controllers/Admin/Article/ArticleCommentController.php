<?php

namespace App\Http\Controllers\Admin\Article;

use App\Http\Controllers\Controller;
use App\Models\Article;
use App\Models\Comment;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use Carbon\Carbon;

class ArticleCommentController extends Controller
{
    public function store(Request $request)
    {
        $comment = new Comment;

        $comment->comment = $request->comment;
        if ($request->hasFile('attachment')) {
            if ($request->file('attachment')->isValid()) {
                $this->validate($request, [
                    'attachment' => 'required|mimes:jpeg,png,jpg,zip,pdf'
                ]);
                $file = $request->file('attachment');
                $destinationPath = public_path('/uploads');
                //$extension = $file->getClientOriginalExtension('logo');
                $image = $file->getClientOriginalName('attachment');
                $image = rand().$image;
                $request->file('attachment')->move($destinationPath, $image);
                $comment->attachment = $image;

            }
        }
        $comment->user()->associate($request->user());

        $article = Article::find($request->article_id);

        $article->comments()->save($comment);
        $article->updated_at =   Carbon::now();
        $article->save();
        return back();
    }

public function delete( $id)
    {
        $comment = Comment::find($id);
        if (Auth::user()->role == 3 or Auth::user()->role == 1){

            $comment->delete();
            Session::flash('success_message', 'Success! Comment has been delete successfully!');
        }elseif(Auth::user()->role == 2 and $comment->user_id == Auth::user()->id){
            $comment->delete();
            Session::flash('success_message', 'Success! Comment has been delete successfully!');
        }else{
            Session::flash('error_message', 'Sorry! You dont have right to Delete this Comment!');
        }

        return back();
    }

    public function replyStore(Request $request)
    {
        $reply = new Comment();

        $reply->comment = $request->get('comment');

        $reply->user()->associate($request->user());

        $reply->parent_id = $request->get('comment_id');

        $article = Article::find($request->get('article_id'));

        $article->comments()->save($reply);
        $article->save();
        return back();

    }
}
