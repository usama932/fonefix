<?php

namespace App\Http\Controllers\Admin\Users;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;


class AdminController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if (Auth::user()->role == 1){
            $title = ' Admin Dashboard';
            return view('admin.dashboard.index',compact('title'));
        }else{
            $title = ' User Dashboard';
            return view('admin.dashboard.user',compact('title'));
        }

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(){
        $user = Auth::user();
        return view('admin.settings.edit', ['title' => 'Edit Admin Profile','user'=>$user]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        $admin = Auth::user();
        $this->validate($request, [
            'name' => 'required|max:255',
            'email' => 'required|unique:users,email,'.$admin->id,
        ]);
        $input = $request->all();
        if (empty($input['password'])) {
            $input['password'] = $admin->password;
        } else {
            $input['password'] = bcrypt($input['password']);
        }
        $admin->fill($input)->save();
        Session::flash('success_message', 'Great! admin successfully updated!');
        return redirect()->back();
    }


    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
    public function saveChangePassword( Request $request )
    { 
        dd($request->all());
        $this->validate($request, [
            'current_password' => 'required',
            'new_password' => 'min:8',
            'password_confirmation' => 'required_with:new_password|same:new_password|min:8'
        ]);
        $id = decrypt($request->id); 
       
        $request['id'] = $id;
        // $password =  $this->UserRepository->changePassword($request);
        $update_request = $request->except('_token','_method');
             $user = User::find($request->id);
            if($user){
                if(Hash::check($request->current_password, $user->password)){
                     $update_request['password'] = Hash::make($request->new_password);
                     $user = $user->update($update_request);
                     return response()->json(['status' => true, 'msg' => "Password changed!"]); 


                }else{
                    return response()->json(['status' => false, 'msg' => "Invalid old password"]); 
                }
       
       
    }
}
}