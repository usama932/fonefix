<?php

namespace App\Http\Controllers\Admin\Users;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class SupervisorController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $title = 'Supervisors';
        return view('admin.supervisors.index',compact('title'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function getSupervisors(Request $request){
        $columns = array(
            0 => 'id',
            1 => 'name',
            2 => 'email',
            3 => 'Status',
            4 => 'created_at',
            5 => 'action'
        );

        $totalData = User::where('role',3)->count();
        $limit = $request->input('length');
        $start = $request->input('start');
        $order = $columns[$request->input('order.0.column')];
        $dir = $request->input('order.0.dir');

        if(empty($request->input('search.value'))){
            $users = User::where('role',3)->offset($start)
                ->limit($limit)
                ->orderBy($order,$dir)
                ->get();
            $totalFiltered = User::where('role',3)->count();
        }else{
            $search = $request->input('search.value');
            $users = User::where([
                ['role',3],
                ['name', 'like', "%{$search}%"],
            ])
                ->orWhere('email','like',"%{$search}%")
                ->orWhere('created_at','like',"%{$search}%")
                ->offset($start)
                ->limit($limit)
                ->orderBy($order, $dir)
                ->get();
            $totalFiltered = User::where([
                ['role',3],
                ['name', 'like', "%{$search}%"],
            ])
                ->orWhere('name', 'like', "%{$search}%")
                ->orWhere('email','like',"%{$search}%")
                ->orWhere('created_at','like',"%{$search}%")
                ->count();
        }


        $data = array();

        if($users){
            foreach($users as $r){
                $edit_url = route('supervisors.edit',$r->id);
                $nestedData['id'] = '<td><label class="checkbox checkbox-outline checkbox-success"><input type="checkbox" name="supervisors[]" value="'.$r->id.'"><span></span></label></td>';
                $nestedData['name'] = $r->name;
                $nestedData['email'] = $r->email;
                if($r->active){
                    $nestedData['status_id'] = '<span class="label label-success label-inline mr-2">Active</span>';
                }else{
                    $nestedData['status_id'] = '<span class="label label-danger label-inline mr-2">Inactive</span>';
                }

                $nestedData['created_at'] = date('d-m-Y',strtotime($r->created_at));
                $nestedData['action'] = '
                                <div>
                                <td>
                                    <a class="btn btn-sm btn-clean btn-icon" onclick="event.preventDefault();viewInfo('.$r->id.');" title="View Supervisor" href="javascript:void(0)">
                                        <i class="icon-1x text-dark-50 flaticon-eye"></i>
                                    </a>
                                    <a title="Edit Supervisor" class="btn btn-sm btn-clean btn-icon"
                                       href="'.$edit_url.'">
                                       <i class="icon-1x text-dark-50 flaticon-edit"></i>
                                    </a>
                                    <a class="btn btn-sm btn-clean btn-icon" onclick="event.preventDefault();del('.$r->id.');" title="Delete Supervisor" href="javascript:void(0)">
                                        <i class="icon-1x text-dark-50 flaticon-delete"></i>
                                    </a>
                                </td>
                                </div>
                            ';
                $data[] = $nestedData;
            }
        }

        $json_data = array(
            "draw"			=> intval($request->input('draw')),
            "recordsTotal"	=> intval($totalData),
            "recordsFiltered" => intval($totalFiltered),
            "data"			=> $data
        );

        echo json_encode($json_data);

    }
    public function create()
    {
        $title = 'Add New Supervisor';
        return view('admin.supervisors.create',compact('title'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request, [
            'name' => 'required|max:255',
            'email' => 'required|unique:users,email',
            'password' => 'required|min:6',
        ]);

        $input = $request->all();
        $user = new User();
        $user->name = $input['name'];
        $user->email = $input['email'];
        $res = array_key_exists('status_id', $input);
        if ($res == false) {
            $user->active = 0;
        } else {
            $user->active = 1;

        }
        $user->password = bcrypt($input['password']);
        $user->save();

        Session::flash('success_message', 'Great! Supervisor has been saved successfully!');
        $user->save();
        return redirect()->back();
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $user = User::find($id);
        return view('admin.supervisors.single', ['title' => 'Supervisor detail', 'user' => $user]);
    }

    public function supervisorDetail(Request $request)
    {

        $user = User::findOrFail($request->id);


        return view('admin.supervisors.detail', ['title' => 'Supervisor Detail', 'user' => $user]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $user = User::find($id);
        return view('admin.supervisors.edit', ['title' => 'Edit supervisor details'])->withUser($user);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $user = User::find($id);
        $this->validate($request, [
            'name' => 'required|max:255',
            'email' => 'required|unique:users,email,'.$user->id,
        ]);
        $input = $request->all();

        $user->name = $input['name'];
        $user->email = $input['email'];
        $res = array_key_exists('status_id', $input);
        if ($res == false) {
            $user->active = 0;
        } else {
            $user->active = 1;

        }
        if(!empty($input['password'])) {
            $user->password = bcrypt($input['password']);
        }

        $user->save();

        Session::flash('success_message', 'Great! Supervisor successfully updated!');
        return redirect()->back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $user = User::find($id);
        if($user->role == 3){
            $user->delete();
            Session::flash('success_message', 'User successfully deleted!');
        }
        return redirect()->route('supervisors.index');

    }
    public function deleteSelectedSupervisors(Request $request)
    {
        $input = $request->all();
        $this->validate($request, [
            'supervisors' => 'required',

        ]);
        foreach ($input['supervisors'] as $index => $id) {

            $user = User::find($id);
            if($user->role == 3){
                $user->delete();
            }

        }
        Session::flash('success_message', 'clietns successfully deleted!');
        return redirect()->back();

    }
}
