<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function casLogin()
    {
        dd("method access");
        if (cas()->isAuthenticated()){
            dd("login");
        }else{
            dd("not loged in");
        }
    }
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        return view('home');
    }
    public function updateProfile()
    {
        $user = Auth::user();
        // dd($user);

        return view('updateProfile',compact('user'));
    }
    public function adminHome()
    {
        return view('admin-home');
    }
}
